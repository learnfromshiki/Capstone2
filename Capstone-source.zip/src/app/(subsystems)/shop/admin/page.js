'use client';

import { useState, useEffect } from 'react';
// Shares the storefront client: sessions are per tab, so signing in as an admin
// from the shop carries into this page instead of asking for the password again.
import { supabase, clearStoredSession, startAdminSession } from '@/lib/supabaseClient';
import { goToShop, showSigningOut } from '@/lib/signOutScreen';
import { getAccountRole } from '@/lib/roles';
import { allowedStatusesFor, formatOrderNumber, isCountedSale, isMissingFunction, isPickup, paymentLabel, statusLabel, STATUS_LABELS, transitionOrderStatus } from '@/lib/orders';
import OnlinePaymentStatus from '@/components/shop/OnlinePaymentStatus';
import { DEFAULT_SHOP_SETTINGS, fetchShopSettings } from '@/lib/shopSettings';
import PasswordRequirements from '@/components/PasswordRequirements';
import { describePasswordProblem, isPasswordValid } from '@/lib/passwordPolicy';

const peso = (value) =>
  `₱${(Number(value) || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
import Link from 'next/link';
import { useDialog } from '@/components/ui/Dialog';
import AvatarUpload from '@/components/ui/AvatarUpload';
import NotificationCenter from '@/components/ui/NotificationCenter';
import NavBadge from '@/components/ui/NavBadge';
import useLiveBadges from '@/lib/useLiveBadges';
import { requestBadgeRefresh } from '@/lib/badges';
import PaymentProof from '@/components/shop/PaymentProof';
import { describeSelection } from '@/lib/productOptions';
import { describeArea, listShippingRates } from '@/lib/shipping';

/**
 * Row action buttons. Soft tinted fills instead of solid saturated colours, so
 * a long table of actions is easy on the eyes; the colour still says what the
 * button does (green approves, red removes, amber pauses).
 */
const ACTION_BASE =
  'inline-flex min-h-[36px] items-center justify-center rounded-lg px-3 py-1.5 text-sm font-medium ring-1 ring-inset transition-colors focus:outline-none focus-visible:ring-2 disabled:cursor-not-allowed disabled:opacity-40';
const ACTION_STYLES = {
  approve: `${ACTION_BASE} bg-emerald-50 text-emerald-700 ring-emerald-200 hover:bg-emerald-100 focus-visible:ring-emerald-400`,
  reject: `${ACTION_BASE} bg-white text-gray-700 ring-gray-300 hover:bg-gray-50 focus-visible:ring-gray-400`,
  danger: `${ACTION_BASE} bg-white text-rose-600 ring-rose-200 hover:bg-rose-50 focus-visible:ring-rose-300`,
  pause: `${ACTION_BASE} bg-amber-50 text-amber-800 ring-amber-200 hover:bg-amber-100 focus-visible:ring-amber-400`,
  resume: `${ACTION_BASE} bg-sky-50 text-sky-700 ring-sky-200 hover:bg-sky-100 focus-visible:ring-sky-400`,
};

const REPORT_CONFIG = {
  sales: {
    title: 'Sales Report',
    subtitle: 'Sales grouped by day (cancelled and unpaid online orders excluded)',
    columns: [
      { key: 'date', label: 'Date' },
      { key: 'orders', label: 'Orders' },
      { key: 'items', label: 'Items (PHP)' },
      { key: 'delivery', label: 'Delivery (PHP)' },
      { key: 'points', label: 'Paid with Points (PHP)' },
      { key: 'revenue', label: 'Collected (PHP)' }
    ]
  },
  products: {
    title: 'Product Report',
    subtitle: 'Best selling products by units and revenue',
    columns: [
      { key: 'name', label: 'Product' },
      { key: 'units', label: 'Units Sold' },
      { key: 'revenue', label: 'Revenue (PHP)' }
    ]
  },
  inventory: {
    title: 'Inventory Report',
    subtitle: 'Stock on hand per product, lowest first (low stock = 5 or fewer)',
    columns: [
      { key: 'name', label: 'Product' },
      { key: 'shop', label: 'Shop' },
      { key: 'price', label: 'Price (PHP)' },
      { key: 'stock', label: 'In Stock' },
      { key: 'level', label: 'Stock Level' },
      { key: 'listed', label: 'Listing' },
      { key: 'sold', label: 'Units Sold' },
      { key: 'value', label: 'Stock Value (PHP)' }
    ]
  },
  customers: {
    title: 'Customer Report',
    subtitle: 'Top customers by total spend',
    columns: [
      { key: 'name', label: 'Customer' },
      { key: 'email', label: 'Email' },
      { key: 'orders', label: 'Orders' },
      { key: 'spent', label: 'Total Spent (PHP)' }
    ]
  },
  sellers: {
    title: 'Seller Report',
    subtitle: 'Sales performance per seller',
    columns: [
      { key: 'name', label: 'Seller' },
      { key: 'products', label: 'Listings' },
      { key: 'units', label: 'Units Sold' },
      { key: 'revenue', label: 'Sales (PHP)' }
    ]
  },
  orders: {
    title: 'Order Report',
    subtitle: 'Order count and value by status',
    columns: [
      { key: 'status', label: 'Status' },
      { key: 'orders', label: 'Orders' },
      { key: 'value', label: 'Value (PHP)' }
    ]
  },
  revenue: {
    title: 'Revenue Report',
    subtitle: 'Revenue breakdown by payment method',
    columns: [
      { key: 'method', label: 'Payment Method' },
      { key: 'orders', label: 'Orders' },
      { key: 'revenue', label: 'Revenue (PHP)' }
    ]
  }
};

export default function ShopAdminPage() {
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [orderStatusFilter, setOrderStatusFilter] = useState('all');
  const [orderSearch, setOrderSearch] = useState('');
  const [categories, setCategories] = useState([]);
  const [sellers, setSellers] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [stats, setStats] = useState({
    totalOrders: 0,
    totalCustomers: 0,
    totalSellers: 0,
    totalSales: 0,
    pendingSellers: 0,
    toFulfill: 0
  });
  const [activeTab, setActiveTab] = useState('dashboard');
  const [salesDaily, setSalesDaily] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  // "Reset marketplace data" in Settings
  const [resetOptions, setResetOptions] = useState({ reviews: false, messages: false, notifications: true });
  const [resetConfirm, setResetConfirm] = useState('');
  const [resetting, setResetting] = useState(false);
  const [checkingAuth, setCheckingAuth] = useState(true);
  const [adminEmail, setAdminEmail] = useState('');
  const [adminName, setAdminName] = useState('Admin');
  const [adminPassword, setAdminPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [loginLoading, setLoginLoading] = useState(false);
  const [websiteSettings, setWebsiteSettings] = useState({ ...DEFAULT_SHOP_SETTINGS });
  const [savingSettings, setSavingSettings] = useState(false);
  const [report, setReport] = useState(null);
  const [reportLoading, setReportLoading] = useState('');
  const [passwordForm, setPasswordForm] = useState({
    current: '',
    next: '',
    confirm: ''
  });
  const [adminUserId, setAdminUserId] = useState(null);
  const [adminAvatarUrl, setAdminAvatarUrl] = useState('');
  const [notices, setNotices] = useState({
    pendingSellers: 0,
    pendingSellerName: '',
    pendingOrders: 0,
    preparingOrders: 0,
    ordersToday: 0,
    outOfStock: 0,
    suspendedCustomers: 0,
  });
  const [shippingRates, setShippingRates] = useState([]);
  const [shippingReady, setShippingReady] = useState(true);
  const [savingShipping, setSavingShipping] = useState(false);
  const [newRate, setNewRate] = useState({ province: '', city: '', fee: '', free_threshold: '' });

  // Site-wide notifications: a modal for anything that must be read or
  // confirmed, a corner toast for routine successes.
  const { showAlert, showConfirm, showToast } = useDialog();
  
  // Live counts for the sidebar badges. A new order, shop application or
  // stock change also reloads the open tab and the bell's to-do list.
  const { counts: liveCounts } = useLiveBadges('admin', {
    enabled: isAuthenticated,
    onChange: () => {
      loadNotices();
      fetchData();
    },
  });

  // Verify admin access: a real Supabase account with the admin role.
  useEffect(() => {
    const verifyAdminAccess = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();

        if (!session?.user) return;

        const role = await getAccountRole(session.user.id, supabase);

        if (role === 'admin') {
          // Keep the admin session inside this tab only (see supabaseClient.js)
          startAdminSession();
          setIsAuthenticated(true);
          setAdminUserId(session.user.id);
          setAdminEmail(session.user.email || '');
          setAdminName(session.user.user_metadata?.full_name || 'Admin');

          const { data: adminProfile } = await supabase
            .from('profiles')
            .select('avatar_url, full_name')
            .eq('id', session.user.id)
            .maybeSingle();

          if (adminProfile) {
            setAdminAvatarUrl(adminProfile.avatar_url || '');
            if (adminProfile.full_name) setAdminName(adminProfile.full_name);
          }
        }
      } catch (error) {
        console.error('Error verifying admin access:', error);
      }
    };

    verifyAdminAccess().finally(() => setCheckingAuth(false));
  }, []);

  useEffect(() => {
    if (isAuthenticated) {
      fetchCategories();
      fetchData();
      fetchSettings();
      loadShippingRates();
      loadNotices();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, isAuthenticated]);

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('shop_categories')
        .select('*')
        .eq('is_active', true)
        .order('display_order', { ascending: true });

      if (error) {
        console.warn('Categories table may not exist yet:', error);
        return;
      }
      setCategories(data || []);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  /**
   * The counts behind the notification bell. Kept separate from the tab data
   * so the bell is right no matter which tab is open.
   */
  const loadNotices = async () => {
    try {
      const startOfDay = new Date();
      startOfDay.setHours(0, 0, 0, 0);

      const [waiting, pending, preparing, todays, soldOut, suspended] = await Promise.all([
        supabase
          .from('shop_sellers')
          .select('business_name', { count: 'exact' })
          .eq('is_approved', false)
          .neq('is_active', false)
          .limit(1),
        supabase.from('shop_orders').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
        supabase
          .from('shop_orders')
          .select('id', { count: 'exact', head: true })
          .in('status', ['confirmed', 'processing']),
        supabase
          .from('shop_orders')
          .select('id', { count: 'exact', head: true })
          .gte('created_at', startOfDay.toISOString()),
        supabase.from('shop_products').select('id', { count: 'exact', head: true }).eq('stock', 0),
        supabase.from('profiles').select('id', { count: 'exact', head: true }).eq('is_suspended', true),
      ]);

      setNotices({
        pendingSellers: waiting.count || 0,
        pendingSellerName: waiting.data?.[0]?.business_name || '',
        pendingOrders: pending.count || 0,
        preparingOrders: preparing.count || 0,
        ordersToday: todays.count || 0,
        outOfStock: soldOut.count || 0,
        suspendedCustomers: suspended.count || 0,
      });
    } catch (error) {
      console.warn('Could not load notifications:', error?.message || error);
    }
  };

  const loadShippingRates = async () => {
    try {
      const { rates, ready } = await listShippingRates();
      setShippingRates(rates);
      setShippingReady(ready);
    } catch (error) {
      console.warn('Could not load the delivery fees:', error.message);
    }
  };

  /** Save one row's fee and free-delivery threshold. */
  const saveShippingRate = async (rate) => {
    setSavingShipping(true);
    try {
      const { error } = await supabase
        .from('shop_shipping_rates')
        .update({
          fee: Number(rate.fee) || 0,
          free_threshold: rate.free_threshold === '' || rate.free_threshold === null
            ? null
            : Number(rate.free_threshold),
          is_active: rate.is_active !== false,
          updated_at: new Date().toISOString(),
        })
        .eq('id', rate.id);

      if (error) throw error;
      showToast(`Delivery fee for ${describeArea(rate)} saved.`, 'success');
      loadShippingRates();
    } catch (error) {
      showAlert('Could not save the delivery fee: ' + error.message);
    } finally {
      setSavingShipping(false);
    }
  };

  const addShippingRate = async () => {
    const province = newRate.province.trim();
    const city = newRate.city.trim();
    const fee = Number(newRate.fee);

    if (!Number.isFinite(fee) || fee < 0) {
      showAlert('Please enter a delivery fee of zero or more.');
      return;
    }

    if (city && !province) {
      showAlert('A city needs its province, so the right fee can be matched.');
      return;
    }

    setSavingShipping(true);
    try {
      const { error } = await supabase.from('shop_shipping_rates').insert({
        province: province || null,
        city: city || null,
        fee,
        free_threshold: newRate.free_threshold === '' ? null : Number(newRate.free_threshold),
      });

      if (error) {
        if (error.code === '23505') throw new Error('There is already a fee for that area.');
        throw error;
      }

      setNewRate({ province: '', city: '', fee: '', free_threshold: '' });
      showToast('Delivery area added.', 'success');
      loadShippingRates();
    } catch (error) {
      showAlert('Could not add the area: ' + error.message);
    } finally {
      setSavingShipping(false);
    }
  };

  const deleteShippingRate = async (rate) => {
    const confirmed = await showConfirm({
      tone: 'error',
      title: 'Remove this delivery area?',
      message: `Orders going to ${describeArea(rate)} will fall back to a wider rate.`,
      confirmLabel: 'Remove area',
    });
    if (!confirmed) return;

    try {
      const { error } = await supabase.from('shop_shipping_rates').delete().eq('id', rate.id);
      if (error) throw error;
      showToast('Delivery area removed.', 'success');
      loadShippingRates();
    } catch (error) {
      showAlert('Could not remove the area: ' + error.message);
    }
  };

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('shop_settings')
        .select('key, value');

      // Settings table is optional until supabase-admin-policies.sql is run
      if (error) return;

      if (data?.length) {
        const stored = data.reduce((acc, row) => ({ ...acc, [row.key]: row.value }), {});
        setWebsiteSettings((prev) => ({ ...prev, ...stored }));
      }
    } catch (error) {
      console.error('Error loading website settings:', error);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoginError('');
    setLoginLoading(true);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: adminEmail.trim(),
        password: adminPassword
      });

      if (error || !data?.user) {
        setLoginError('Invalid email or password');
        return;
      }

      const role = await getAccountRole(data.user.id, supabase);

      if (role !== 'admin') {
        // Signed in, but this account is a buyer or seller - do not grant admin access
        await supabase.auth.signOut();
        setLoginError('This account does not have admin access.');
        return;
      }

      startAdminSession();
      setIsAuthenticated(true);
      setAdminUserId(data.user.id);
      setAdminName(data.user.user_metadata?.full_name || 'Admin');
      setAdminEmail(data.user.email || adminEmail.trim());
    } catch (error) {
      console.error('Admin login error:', error);
      setLoginError('Unable to sign in right now. Please try again.');
    } finally {
      setLoginLoading(false);
    }
  };

  const handleLogout = async () => {
    const confirmed = await showConfirm({
      tone: 'question',
      title: 'Log out of the admin panel?',
      message: 'You will need to sign in again to manage the marketplace.',
      confirmLabel: 'Log out',
      cancelLabel: 'Stay signed in',
    });
    if (!confirmed) return;

    // Cover the panel first: clearing the session would otherwise flash the
    // admin login form on the way to the shop.
    showSigningOut();

    try {
      await supabase.auth.signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }

    // Also ends this tab's admin mode, so the next login here is a normal one.
    clearStoredSession();
    goToShop();
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      if (activeTab === 'dashboard') {
        // Fetch all stats AND recent orders for dashboard
        const [ordersRes, customersRes, sellersRes, recentOrdersRes] = await Promise.all([
          supabase.from('shop_orders').select('total_amount, status, created_at, payment_method, payment_status', { count: 'exact' }),
          supabase.from('profiles').select('id, user_type'),
          supabase.from('shop_sellers').select('is_approved, is_rejected, user_id', { count: 'exact' }),
          supabase.from('shop_orders').select('*, shop_order_items(*)').order('created_at', { ascending: false }).limit(10)
        ]);

        // Cancelled orders are refunds, not revenue
        const paidOrders = ordersRes.data?.filter(isCountedSale) || [];
        const totalSales = paidOrders.reduce((sum, order) => sum + (Number(order.total_amount) || 0), 0);
        const pendingSellers = sellersRes.data?.filter(s => !s.is_approved && !s.is_rejected).length || 0;
        const toFulfill = (ordersRes.data || []).filter(order => ['pending', 'confirmed', 'processing'].includes(order.status)).length;

        // Customers are profiles that are neither sellers nor admins
        const sellerUserIds = new Set((sellersRes.data || []).map(s => s.user_id).filter(Boolean));
        const totalCustomers = (customersRes.data || [])
          .filter(profile => !['admin', 'seller'].includes(profile.user_type) && !sellerUserIds.has(profile.id))
          .length;

        // Last 7 days of revenue for the dashboard chart
        const days = [];
        for (let offset = 6; offset >= 0; offset -= 1) {
          const date = new Date();
          date.setDate(date.getDate() - offset);
          days.push({
            key: date.toLocaleDateString('en-CA'),
            label: date.toLocaleDateString('en-US', { weekday: 'short' }),
            total: 0
          });
        }

        paidOrders.forEach(order => {
          const key = new Date(order.created_at).toLocaleDateString('en-CA');
          const day = days.find(entry => entry.key === key);
          if (day) day.total += Number(order.total_amount) || 0;
        });

        setSalesDaily(days);
        setStats({
          totalOrders: ordersRes.count || 0,
          totalCustomers: totalCustomers,
          totalSellers: sellersRes.count || 0,
          totalSales: totalSales,
          pendingSellers: pendingSellers,
          toFulfill: toFulfill
        });
        setOrders(recentOrdersRes.data || []);
      } else if (activeTab === 'sellers') {
        const { data, error } = await supabase
          .from('shop_sellers')
          .select('*')
          .order('created_at', { ascending: false });

        if (error) throw error;
        setSellers(data || []);
      } else if (activeTab === 'customers') {
        const [profilesRes, sellerRowsRes] = await Promise.all([
          supabase.from('profiles').select('*').order('created_at', { ascending: false }),
          supabase.from('shop_sellers').select('user_id'),
        ]);

        if (profilesRes.error) throw profilesRes.error;

        // A customer is a profile that is neither an admin nor a seller account
        const sellerUserIds = new Set(
          (sellerRowsRes.data || []).map((seller) => seller.user_id).filter(Boolean)
        );

        setCustomers(
          (profilesRes.data || []).filter(
            (profile) =>
              !['admin', 'seller'].includes(profile.user_type) && !sellerUserIds.has(profile.id)
          )
        );
      } else if (activeTab === 'products') {
        const { data, error } = await supabase
          .from('shop_products')
          .select('*')
          .order('created_at', { ascending: false });

        if (error) throw error;
        setProducts(data || []);
      } else if (activeTab === 'categories') {
        const { data, error } = await supabase
          .from('shop_categories')
          .select('*')
          .order('display_order', { ascending: true });

        if (error) throw error;
        setCategories(data || []);
      } else {
        const { data, error } = await supabase
          .from('shop_orders')
          .select('*, shop_order_items(*)')
          .order('created_at', { ascending: false });

        if (error) throw error;
        setOrders(data || []);
        // Keep the sidebar badge in sync when the orders tab loads
        setStats((prev) => ({ ...prev, totalOrders: data?.length || 0 }));
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleProductAvailability = async (productId, currentStatus) => {
    try {
      const { data, error } = await supabase
        .from('shop_products')
        .update({ available: !currentStatus })
        .eq('id', productId)
        .select('id');

      if (error) throw error;
      if (!data || data.length === 0) {
        showAlert('Could not update this product. The database blocked the change — run supabase-final-fixes.sql to allow admin writes.');
        return;
      }
      fetchData();
    } catch (error) {
      console.error('Error updating product:', error);
      showAlert('Failed to update product: ' + (error.message || 'unknown error'));
    }
  };

  const deleteProduct = async (productId) => {
    const confirmed = await showConfirm({
      tone: 'error',
      title: 'Delete this product?',
      message: 'It disappears from the storefront. This cannot be undone.',
      confirmLabel: 'Delete product',
    });
    if (!confirmed) return;
    
    try {
      // A product referenced by orders must keep its row so order history stays
      // intact; deactivating hides it from the shop without breaking past orders.
      const { data: orderedItems, error: orderedError } = await supabase
        .from('shop_order_items')
        .select('id')
        .eq('product_id', productId)
        .limit(1);

      if (orderedError) throw orderedError;

      if (orderedItems && orderedItems.length > 0) {
        showAlert('This product is part of existing orders, so it cannot be deleted. Deactivate it instead to hide it from the shop.');
        return;
      }

      const { data, error } = await supabase
        .from('shop_products')
        .delete()
        .eq('id', productId)
        .select('id');

      if (error) throw error;
      if (!data || data.length === 0) {
        showAlert('Could not delete this product. The database blocked the change — run supabase-final-fixes.sql to allow admin writes.');
        return;
      }
      fetchData();
    } catch (error) {
      console.error('Error deleting product:', error);
      showAlert('Failed to delete product: ' + (error.message || 'unknown error'));
    }
  };

  const toggleCategoryActive = async (category) => {
    try {
      const { data, error } = await supabase
        .from('shop_categories')
        .update({ is_active: !category.is_active, updated_at: new Date().toISOString() })
        .eq('id', category.id)
        .select('id');

      if (error) throw error;

      if (!data || data.length === 0) {
        showToast('That category could not be updated. Refresh and try again.', 'error');
        return;
      }

      showToast(
        `Category "${category.name}" ${category.is_active ? 'deactivated' : 'activated'}.`,
        'success'
      );
      fetchCategories();
      fetchData();
    } catch (error) {
      console.error('Error updating category:', error);
      showToast('Failed to update category: ' + (error.message || 'unknown error'), 'error');
    }
  };

  const deleteCategory = async (category) => {
    // "All Products" is a real row but it is the storefront's fallback tab.
    if (category.slug === 'all') {
      showAlert('The "All Products" tab is built into the storefront and cannot be deleted.');
      return;
    }

    try {
      const { count, error: countError } = await supabase
        .from('shop_products')
        .select('id', { count: 'exact', head: true })
        .eq('category', category.slug);

      if (countError) throw countError;

      // Products store the slug, so deleting a used category would orphan their tab.
      if ((count || 0) > 0) {
        showAlert(`"${category.name}" still has ${count} product(s). Move or delete those products first.`);
        return;
      }
    } catch (error) {
      console.error('Error counting products in category:', error);
      showToast('Could not check the products in this category.', 'error');
      return;
    }

    const confirmed = await showConfirm({
      tone: 'error',
      title: `Delete the category "${category.name}"?`,
      message: 'The tab disappears from the storefront. This cannot be undone.',
      confirmLabel: 'Delete category',
    });
    if (!confirmed) return;

    try {
      const { data, error } = await supabase
        .from('shop_categories')
        .delete()
        .eq('id', category.id)
        .select('id');

      if (error) throw error;

      if (!data || data.length === 0) {
        showToast('That category could not be deleted. Refresh and try again.', 'error');
        return;
      }

      showToast(`Category "${category.name}" deleted.`, 'success');
      fetchCategories();
      fetchData();
    } catch (error) {
      console.error('Error deleting category:', error);
      showToast('Failed to delete category: ' + (error.message || 'unknown error'), 'error');
    }
  };

  const deleteCustomer = async (customer) => {
    const name = customer.full_name || customer.email || 'this customer';

    const confirmed = await showConfirm({
      tone: 'error',
      title: `Delete "${name}" permanently?`,
      message:
        'Their account is removed from Supabase: login, profile, reward points, cart and messages. Orders they had not received yet are cancelled. Past orders stay in Transactions so sales records are not lost. This cannot be undone.',
      confirmLabel: 'Delete customer',
    });
    if (!confirmed) return;

    try {
      // Deletes the login as well as the profile. Removing only the profile
      // left an account that could sign in but never check out.
      const { error } = await supabase.rpc('admin_delete_account', { p_user_id: customer.id });

      if (error) {
        if (isMissingFunction(error)) {
          showToast('Deleting customers needs supabase-admin-delete-accounts.sql. Run it in Supabase first.', 'error');
          return;
        }
        throw error;
      }

      showToast(`${name} was deleted from the system.`, 'success');
      fetchData();
    } catch (error) {
      console.error('Error deleting customer:', error);
      showToast('Failed to delete customer: ' + (error.message || 'unknown error'), 'error');
    }
  };

  const deleteSeller = async (seller) => {
    const name = seller.business_name || 'this seller';

    const confirmed = await showConfirm({
      tone: 'error',
      title: `Delete "${name}" permanently?`,
      message:
        'The shop and the owner account are removed from Supabase, including their login. Orders the shop had not shipped yet are cancelled and the customers get their stock and points back. Products that were never ordered are deleted; products in past orders are hidden so sales records stay intact. This cannot be undone.',
      confirmLabel: 'Delete seller',
    });
    if (!confirmed) return;

    try {
      // One database call: products without orders are deleted, products that
      // appear in past orders are hidden (they cannot be deleted), then the
      // shop and its login are removed. Doing this from the browser left
      // ordered products on sale with no owner.
      const { error } = await supabase.rpc('admin_delete_seller', { p_seller_id: seller.id });

      if (error) {
        if (isMissingFunction(error)) {
          showToast('Deleting sellers needs supabase-admin-delete-accounts.sql. Run it in Supabase first.', 'error');
          return;
        }
        throw error;
      }

      showToast(`Seller "${name}" was deleted from the system.`, 'success');
      fetchData();
    } catch (error) {
      console.error('Error deleting seller:', error);
      showToast('Failed to delete seller: ' + (error.message || 'unknown error'), 'error');
    }
  };

  const updateOrderStatus = async (orderId, newStatus) => {
    const order = orders.find((entry) => entry.id === orderId);

    if (!order || order.status === newStatus) return;

    if (newStatus === 'cancelled') {
      const confirmed = await showConfirm({
        tone: 'warning',
        title: 'Cancel this order?',
        message: 'The items go back into stock and the order cannot be reopened.',
        confirmLabel: 'Cancel order',
        cancelLabel: 'Keep order',
      });
      if (!confirmed) return;
    }

    try {
      const result = await transitionOrderStatus(orderId, newStatus);

      showToast(
        result.restoredItems > 0
          ? `Order cancelled and ${result.restoredItems} product stock level(s) restored.`
          : `Order marked ${STATUS_LABELS[newStatus] || newStatus}.`,
        'success'
      );
      fetchData();
    } catch (error) {
      console.error('Error updating order:', error);
      showToast('Failed to update order: ' + (error.message || 'unknown error'), 'error');
      fetchData();
    }
  };

  const approveSeller = async (seller) => {
    const confirmed = await showConfirm({
      tone: 'question',
      title: 'Approve this seller?',
      message: `"${seller.business_name}" will be able to list products on the storefront.`,
      confirmLabel: 'Approve seller',
    });
    if (!confirmed) return;

    try {
      const { data, error } = await supabase
        .from('shop_sellers')
        .update({
          is_approved: true,
          is_rejected: false,
          is_active: true,
          updated_at: new Date().toISOString()
        })
        .eq('id', seller.id)
        .select('id');

      if (error) throw error;

      if (!data || data.length === 0) {
        showToast('Could not approve this seller — the database blocked the change. Run supabase-security-hardening.sql.', 'error');
        return;
      }

      showToast(`Seller "${seller.business_name}" approved successfully.`, 'success');
      fetchData();
    } catch (error) {
      console.error('Error approving seller:', error);
      showToast('Failed to approve seller: ' + (error.message || 'unknown error'), 'error');
    }
  };

  const toggleCustomerStatus = async (customer) => {
    const suspending = !customer.is_suspended;
    const name = customer.full_name || customer.email || 'this customer';

    const confirmed = await showConfirm({
      tone: suspending ? 'warning' : 'question',
      title: suspending ? 'Suspend this customer?' : 'Reactivate this customer?',
      message: suspending
        ? `"${name}" will not be able to sign in or place orders until you restore the account.`
        : `"${name}" will be able to shop again.`,
      confirmLabel: suspending ? 'Suspend' : 'Reactivate',
    });
    if (!confirmed) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ is_suspended: suspending, updated_at: new Date().toISOString() })
        .eq('id', customer.id);

      if (error) throw error;

      showToast(`${name} ${suspending ? 'suspended' : 'reactivated'}.`, 'success');
      fetchData();
    } catch (error) {
      console.error('Error updating customer status:', error);
      showToast(
        error.message?.includes('is_suspended')
          ? 'Suspending needs the is_suspended column. Run supabase-admin-policies.sql in Supabase.'
          : 'Failed to update customer: ' + error.message,
        'error'
      );
    }
  };

  const rejectSeller = async (seller) => {
    const confirmed = await showConfirm({
      tone: 'warning',
      title: 'Reject this application?',
      message: `"${seller.business_name}" will not be able to sell on CONNECT-Daet.`,
      confirmLabel: 'Reject application',
    });
    if (!confirmed) return;

    try {
      const { error } = await supabase
        .from('shop_sellers')
        .update({
          is_rejected: true,
          is_approved: false,
          is_active: false,
          updated_at: new Date().toISOString()
        })
        .eq('id', seller.id);

      if (error) throw error;

      showToast(`Seller application "${seller.business_name}" rejected.`, 'success');
      fetchData();
    } catch (error) {
      console.error('Error rejecting seller:', error);
      showToast(
        error.message?.includes('is_rejected')
          ? 'Rejecting needs the is_rejected column. Run supabase-admin-policies.sql in Supabase.'
          : 'Failed to reject seller: ' + error.message,
        'error'
      );
    }
  };

  const orderTotals = orders.reduce(
    (acc, order) => {
      const amount = Number(order.total_amount) || 0;
      const isCancelled = order.status === 'cancelled';

      if (order.status === 'delivered') acc.completed += amount;
      else if (isCancelled) acc.refunded += amount;
      else acc.pending += amount;

      // Cancelled orders were refunded, so they are not money received.
      if (!isCancelled) {
        if (order.payment_method === 'cod') acc.cod += amount;
        if (order.payment_method === 'gcash') acc.gcash += amount;
        if (order.payment_method === 'bank') acc.bank += amount;
        if (order.payment_method === 'xendit' && order.payment_status === 'paid') acc.online += amount;
      }

      return acc;
    },
    { completed: 0, pending: 0, refunded: 0, cod: 0, gcash: 0, bank: 0, online: 0 }
  );

  const generateReport = async (type) => {
    const config = REPORT_CONFIG[type];
    if (!config) return;

    setReportLoading(type);

    try {
      const salesOrders = orders.filter(isCountedSale);
      let rows = [];

      if (type === 'sales') {
        const byDay = {};

        salesOrders.forEach((order) => {
          const day = new Date(order.created_at).toLocaleDateString('en-CA');
          const total = Number(order.total_amount) || 0;
          const delivery = Number(order.shipping_fee) || 0;
          // Reward points the customer spent; the platform covers them.
          const points = Number(order.points_discount) || 0;
          byDay[day] = byDay[day] || { date: day, orders: 0, items: 0, delivery: 0, points: 0, revenue: 0 };
          byDay[day].orders += 1;
          byDay[day].items += total - delivery + points;
          byDay[day].delivery += delivery;
          byDay[day].points += points;
          byDay[day].revenue += total;
        });

        rows = Object.values(byDay)
          .sort((a, b) => b.date.localeCompare(a.date))
          .map((row) => ({
            ...row,
            items: row.items.toFixed(2),
            delivery: row.delivery.toFixed(2),
            points: row.points.toFixed(2),
            revenue: row.revenue.toFixed(2)
          }));
      } else if (type === 'products') {
        // Grouped by product id: a renamed product is still one product.
        const byProduct = {};

        salesOrders.forEach((order) => {
          (order.shop_order_items || []).forEach((item) => {
            const key = item.product_id || item.product_name;
            byProduct[key] = byProduct[key] || { name: item.product_name, units: 0, revenue: 0 };
            byProduct[key].units += Number(item.quantity) || 0;
            byProduct[key].revenue += (Number(item.price) || 0) * (Number(item.quantity) || 0);
          });
        });

        rows = Object.values(byProduct)
          .sort((a, b) => b.revenue - a.revenue)
          .map((row) => ({ ...row, revenue: row.revenue.toFixed(2) }));
      } else if (type === 'inventory') {
        const [{ data: productRows, error: productsError }, { data: sellerRows }] = await Promise.all([
          supabase.from('shop_products').select('id, name, price, stock, available, seller_id'),
          supabase.from('shop_sellers').select('id, business_name')
        ]);

        if (productsError) throw productsError;

        const sellerNames = new Map((sellerRows || []).map((seller) => [seller.id, seller.business_name]));
        const sold = {};
        salesOrders.forEach((order) => {
          (order.shop_order_items || []).forEach((item) => {
            if (item.product_id) sold[item.product_id] = (sold[item.product_id] || 0) + (Number(item.quantity) || 0);
          });
        });

        rows = (productRows || [])
          .map((product) => {
            const stock = Number(product.stock) || 0;
            const price = Number(product.price) || 0;
            return {
              name: product.name,
              shop: product.seller_id ? sellerNames.get(product.seller_id) || 'Unknown shop' : 'Platform',
              price: price.toFixed(2),
              stock,
              level: stock <= 0 ? 'Out of stock' : stock <= 5 ? 'Low' : 'OK',
              listed: product.available ? 'Active' : 'Hidden',
              sold: sold[product.id] || 0,
              value: (price * stock).toFixed(2)
            };
          })
          .sort((a, b) => a.stock - b.stock || a.name.localeCompare(b.name));
      } else if (type === 'customers') {
        const byCustomer = {};

        salesOrders.forEach((order) => {
          const key = order.customer_email || order.customer_name || 'Unknown';
          byCustomer[key] = byCustomer[key] || {
            name: order.customer_name || 'Unknown',
            email: order.customer_email || '-',
            orders: 0,
            spent: 0
          };
          byCustomer[key].orders += 1;
          byCustomer[key].spent += Number(order.total_amount) || 0;
        });

        rows = Object.values(byCustomer)
          .sort((a, b) => b.spent - a.spent)
          .map((row) => ({ ...row, spent: row.spent.toFixed(2) }));
      } else if (type === 'sellers') {
        const [{ data: sellerRows }, { data: productRows }] = await Promise.all([
          supabase.from('shop_sellers').select('id, business_name'),
          supabase.from('shop_products').select('id, seller_id')
        ]);

        const sellerNames = new Map((sellerRows || []).map((seller) => [seller.id, seller.business_name]));
        const productSellers = new Map((productRows || []).map((product) => [product.id, product.seller_id]));
        const bySeller = {};

        (productRows || []).forEach((product) => {
          const key = product.seller_id || 'unassigned';
          bySeller[key] = bySeller[key] || {
            name: product.seller_id ? sellerNames.get(product.seller_id) || 'Unknown seller' : 'Platform listings',
            products: 0,
            units: 0,
            revenue: 0
          };
          bySeller[key].products += 1;
        });

        salesOrders.forEach((order) => {
          (order.shop_order_items || []).forEach((item) => {
            const sellerId = productSellers.get(item.product_id) || 'unassigned';
            bySeller[sellerId] = bySeller[sellerId] || {
              name: sellerId === 'unassigned' ? 'Platform listings' : sellerNames.get(sellerId) || 'Unknown seller',
              products: 0,
              units: 0,
              revenue: 0
            };
            bySeller[sellerId].units += item.quantity || 0;
            bySeller[sellerId].revenue += (Number(item.price) || 0) * (item.quantity || 0);
          });
        });

        rows = Object.values(bySeller)
          .sort((a, b) => b.revenue - a.revenue)
          .map((row) => ({ ...row, revenue: row.revenue.toFixed(2) }));
      } else if (type === 'orders') {
        const statuses = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'];

        rows = statuses.map((status) => {
          const matching = orders.filter((order) => order.status === status);
          return {
            status: status.charAt(0).toUpperCase() + status.slice(1),
            orders: matching.length,
            value: matching.reduce((sum, order) => sum + (Number(order.total_amount) || 0), 0).toFixed(2)
          };
        });
      } else if (type === 'revenue') {
        const methods = [
          { key: 'gcash', label: 'GCash' },
          { key: 'cod', label: 'Cash on Delivery' },
          { key: 'bank', label: 'Bank Transfer' },
          { key: 'xendit', label: 'Online (Xendit)' }
        ];

        rows = methods.map((method) => {
          const matching = salesOrders.filter((order) => order.payment_method === method.key);
          return {
            method: method.label,
            orders: matching.length,
            revenue: matching.reduce((sum, order) => sum + (Number(order.total_amount) || 0), 0).toFixed(2)
          };
        });
      }

      setReport({
        type,
        title: config.title,
        subtitle: config.subtitle,
        columns: config.columns,
        rows,
        generatedAt: new Date().toLocaleString()
      });

      showToast(
        rows.length
          ? `${config.title} generated: ${rows.length} row(s).`
          : `${config.title} generated, but there is no data yet.`,
        'success'
      );
    } catch (error) {
      console.error('Error generating report:', error);
      showToast('Failed to generate report: ' + error.message, 'error');
    } finally {
      setReportLoading('');
    }
  };

  const exportReportCsv = () => {
    if (!report || report.rows.length === 0) {
      showToast('Generate a report with data before exporting.', 'error');
      return;
    }

    const escape = (value) => `"${String(value ?? '').replace(/"/g, '""')}"`;
    const lines = [
      report.columns.map((column) => escape(column.label)).join(','),
      ...report.rows.map((row) => report.columns.map((column) => escape(row[column.key])).join(','))
    ];

    const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${report.type}-report-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast('CSV file downloaded.', 'success');
  };

  /**
   * Print the report, not the dashboard.
   *
   * window.print() on this page sent the sidebar, the tab strip and every
   * button to the printer, which is what made printing look broken. The report
   * is written into a window of its own instead, so what comes out is a clean
   * table with a heading and a date - and "Save as PDF" from that dialog gives
   * a usable PDF.
   */
  // The admin shell is a full-height column that scrolls inside its own main
  // area. Without this the page behind it scrolls too, and the browser draws a
  // second scrollbar down the right-hand edge.
  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    return () => {
      document.body.style.overflow = previous;
    };
  }, []);

  const printReport = () => {
    if (!report || report.rows.length === 0) {
      showToast('Generate a report with data before printing.', 'error');
      return;
    }

    const escapeHtml = (value) =>
      String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');

    const head = report.columns.map((column) => `<th>${escapeHtml(column.label)}</th>`).join('');
    const body = report.rows
      .map(
        (row) =>
          `<tr>${report.columns.map((column) => `<td>${escapeHtml(row[column.key])}</td>`).join('')}</tr>`
      )
      .join('');

    const html = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>${escapeHtml(report.title)} - CONNECT-Daet.ph</title>
    <style>
      * { box-sizing: border-box; }
      body { font-family: Arial, Helvetica, sans-serif; color: #111827; margin: 32px; }
      h1 { font-size: 20px; margin: 0 0 4px; }
      p.meta { font-size: 12px; color: #6b7280; margin: 0 0 20px; }
      table { width: 100%; border-collapse: collapse; font-size: 12px; }
      th, td { border: 1px solid #d1d5db; padding: 8px 10px; text-align: left; }
      th { background: #f3f4f6; font-weight: bold; }
      tr:nth-child(even) td { background: #fafafa; }
      footer { margin-top: 24px; font-size: 11px; color: #9ca3af; }
      @page { margin: 16mm; }
    </style>
  </head>
  <body>
    <h1>${escapeHtml(report.title)}</h1>
    <p class="meta">${escapeHtml(report.subtitle)} &middot; Generated ${escapeHtml(report.generatedAt)}</p>
    <table>
      <thead><tr>${head}</tr></thead>
      <tbody>${body}</tbody>
    </table>
    <footer>CONNECT-Daet.ph &middot; ${escapeHtml(String(report.rows.length))} row(s)</footer>
  </body>
</html>`;

    const printWindow = window.open('', '_blank', 'width=900,height=700');

    if (!printWindow) {
      showToast('Your browser blocked the print window. Allow pop-ups for this site and try again.', 'error');
      return;
    }

    printWindow.document.open();
    printWindow.document.write(html);
    printWindow.document.close();
    printWindow.focus();

    // Give the window a moment to lay the table out before the dialog opens.
    setTimeout(() => {
      printWindow.print();
    }, 250);
  };

  const updateAdminProfile = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();

      if (!session?.user) {
        showToast('Your session has expired. Please sign in again.', 'error');
        return;
      }

      const { error } = await supabase
        .from('profiles')
        .update({ full_name: adminName })
        .eq('id', session.user.id);

      if (error) throw error;

      await supabase.auth.updateUser({ data: { full_name: adminName } });
      showToast('Admin profile updated.', 'success');
    } catch (error) {
      console.error('Error updating admin profile:', error);
      showToast('Failed to update profile: ' + error.message, 'error');
    }
  };

  const saveWebsiteSettings = async () => {
    const trimmed = Object.fromEntries(
      Object.entries(websiteSettings).map(([key, value]) => [key, String(value ?? '').trim()])
    );

    if (trimmed.contactEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(trimmed.contactEmail)) {
      showToast('Please enter a valid contact email.', 'error');
      return;
    }

    if (trimmed.gcashNumber && trimmed.gcashNumber.replace(/\D/g, '').length < 10) {
      showToast('Please enter the full 11-digit GCash number (e.g. 0917 123 4567).', 'error');
      return;
    }

    setSavingSettings(true);

    try {
      const rows = Object.entries(trimmed).map(([key, value]) => ({ key, value }));

      const { error } = await supabase.from('shop_settings').upsert(rows, { onConflict: 'key' });

      if (error) throw error;

      setWebsiteSettings(trimmed);
      // Refresh the cached copy that checkout and My Orders read
      fetchShopSettings({ force: true });
      showToast('Website settings saved.', 'success');
    } catch (error) {
      console.error('Error saving website settings:', error);
      showToast(
        error.code === '42P01' || error.message?.includes('shop_settings')
          ? 'Could not save settings: the shop_settings table is missing or blocked. Run supabase-security-hardening.sql in Supabase.'
          : 'Failed to save settings: ' + error.message,
        'error'
      );
    } finally {
      setSavingSettings(false);
    }
  };

  const changeAdminPassword = async () => {
    const passwordProblem = describePasswordProblem(passwordForm.next);
    if (passwordProblem) {
      showToast(passwordProblem, 'error');
      return;
    }

    if (passwordForm.next !== passwordForm.confirm) {
      showToast('New passwords do not match.', 'error');
      return;
    }

    try {
      const { data: { session } } = await supabase.auth.getSession();

      if (!session?.user?.email) {
        showToast('Your session has expired. Please sign in again.', 'error');
        return;
      }

      const { error: verifyError } = await supabase.auth.signInWithPassword({
        email: session.user.email,
        password: passwordForm.current
      });

      if (verifyError) {
        showToast('Current password is incorrect.', 'error');
        return;
      }

      const { error } = await supabase.auth.updateUser({ password: passwordForm.next });
      if (error) throw error;

      setPasswordForm({ current: '', next: '', confirm: '' });
      showToast('Password updated.', 'success');
    } catch (error) {
      console.error('Error changing admin password:', error);
      showToast('Failed to change password: ' + error.message, 'error');
    }
  };

  // Login Screen
  // Things happening across the marketplace that an admin should act on.
  // These counts are loaded on their own (see loadNotices) because the tables
  // above are only fetched for the tab being viewed.
  // Sidebar badges: live counts when nav_badge_counts() is installed, the
  // bell's own counts otherwise. Each one is something waiting for the admin,
  // so it goes down as soon as it is handled.
  const badgeOrders = liveCounts?.orders_to_handle ?? notices.pendingOrders + notices.preparingOrders;
  const badgePendingSellers = liveCounts?.pending_sellers ?? notices.pendingSellers;
  const badgeOutOfStock = liveCounts?.out_of_stock ?? notices.outOfStock;

  /**
   * Clear sales and statistics (and, if ticked, reviews, chats and
   * notifications). Accounts, shops, products and settings stay.
   */
  const resetMarketplace = async () => {
    if (resetConfirm.trim() !== 'RESET' || resetting) return;

    const extras = [
      resetOptions.reviews && 'reviews',
      resetOptions.messages && 'chats',
      resetOptions.notifications && 'notifications',
    ].filter(Boolean);

    const confirmed = await showConfirm({
      tone: 'error',
      title: 'Reset all marketplace data?',
      message:
        'Every order, sale, payment, seller earning and shop reward point is deleted' +
        (extras.length ? `, together with all ${extras.join(', ')}` : '') +
        '. Accounts, shops, products, categories and settings are kept. This cannot be undone.',
      confirmLabel: 'Reset everything',
      cancelLabel: 'Keep my data',
    });
    if (!confirmed) return;

    setResetting(true);
    try {
      const { data, error } = await supabase.rpc('admin_reset_marketplace', {
        p_confirm: 'RESET',
        p_reviews: resetOptions.reviews,
        p_messages: resetOptions.messages,
        p_notifications: resetOptions.notifications,
      });

      if (error) {
        if (isMissingFunction(error)) {
          showAlert('Resetting needs supabase-live-badges-reset.sql. Run it in Supabase first.');
          return;
        }
        throw error;
      }

      setResetConfirm('');
      const removed = Number(data?.orders) || 0;
      showToast(
        removed > 0
          ? `Marketplace reset: ${removed} ${removed === 1 ? 'order' : 'orders'} and all sales statistics cleared.`
          : 'Marketplace reset. Sales and statistics now start from zero.',
        'success'
      );
      requestBadgeRefresh();
      loadNotices();
      fetchData();
    } catch (error) {
      console.error('Error resetting the marketplace:', error);
      showAlert('Could not reset the marketplace: ' + (error.message || 'unknown error'));
    } finally {
      setResetting(false);
    }
  };

  const adminNotifications = [
    notices.pendingSellers > 0 && {
      id: 'pending-sellers',
      icon: '🏪',
      tone: 'warning',
      title:
        notices.pendingSellerName && notices.pendingSellers === 1
          ? `${notices.pendingSellerName} is waiting for approval`
          : `${notices.pendingSellers} shops are waiting for approval`,
      detail: 'They cannot sell until you approve them.',
      count: notices.pendingSellers,
      onClick: () => setActiveTab('sellers'),
    },
    notices.pendingOrders > 0 && {
      id: 'pending-orders',
      icon: '🛒',
      tone: 'info',
      title: `${notices.pendingOrders} ${notices.pendingOrders === 1 ? 'order is' : 'orders are'} still pending`,
      detail: 'Waiting for a shop to confirm them.',
      count: notices.pendingOrders,
      onClick: () => setActiveTab('orders'),
    },
    notices.preparingOrders > 0 && {
      id: 'unfulfilled-orders',
      icon: '📦',
      tone: 'info',
      title: `${notices.preparingOrders} ${notices.preparingOrders === 1 ? 'order is' : 'orders are'} being prepared`,
      detail: 'Confirmed or processing, not yet shipped.',
      count: notices.preparingOrders,
      onClick: () => setActiveTab('orders'),
    },
    notices.ordersToday > 0 && {
      id: 'orders-today',
      icon: '📈',
      tone: 'success',
      title: `${notices.ordersToday} ${notices.ordersToday === 1 ? 'order' : 'orders'} placed today`,
      detail: 'Across every shop on the marketplace.',
      count: notices.ordersToday,
      onClick: () => setActiveTab('orders'),
    },
    notices.outOfStock > 0 && {
      id: 'out-of-stock',
      icon: '⚠️',
      tone: 'danger',
      title: `${notices.outOfStock} ${notices.outOfStock === 1 ? 'product is' : 'products are'} out of stock`,
      detail: 'Shoppers cannot buy them until the shop restocks.',
      count: notices.outOfStock,
      onClick: () => setActiveTab('products'),
    },
    notices.suspendedCustomers > 0 && {
      id: 'suspended-customers',
      icon: '🚫',
      tone: 'warning',
      title: `${notices.suspendedCustomers} suspended ${notices.suspendedCustomers === 1 ? 'customer' : 'customers'}`,
      detail: 'They cannot sign in or order.',
      count: notices.suspendedCustomers,
      onClick: () => setActiveTab('customers'),
    },
  ].filter(Boolean);

  const orderQuery = orderSearch.trim().toLowerCase().replace(/^#/, '');
  const visibleOrders = orders.filter((order) => {
    if (orderStatusFilter !== 'all' && order.status !== orderStatusFilter) return false;
    if (!orderQuery) return true;
    return [order.id, order.customer_name, order.customer_email, order.customer_phone]
      .some((value) => String(value || '').toLowerCase().includes(orderQuery));
  });

  if (checkingAuth) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center p-4">
        <div className="max-w-md w-full">
          <div className="bg-white rounded-2xl shadow-2xl p-8">
            <div className="text-center mb-8">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Admin Access</h1>
              <p className="text-gray-600">Sign in with your admin account</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  value={adminEmail}
                  onChange={(e) => setAdminEmail(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                  placeholder="Enter admin email"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Password
                </label>
                <input
                  type="password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                  placeholder="Enter admin password"
                  required
                />
                {loginError && (
                  <p className="mt-2 text-sm text-red-600 flex items-center gap-1">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                    {loginError}
                  </p>
                )}
              </div>

              <button
                type="submit"
                disabled={loginLoading}
                className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-3.5 rounded-xl font-bold hover:from-blue-700 hover:to-blue-800 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
              >
                {loginLoading ? 'Signing in...' : 'Access Admin Panel'}
              </button>

              <div className="text-center">
                <Link href="/shop" className="text-sm text-gray-600 hover:text-blue-600 transition-colors">
                  ← Back to Shop
                </Link>
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  }

  // Main Admin Dashboard with Sidebar
  return (
    <div className="flex h-screen flex-col overflow-hidden bg-gray-50 lg:flex-row">
      {/* LEFT SIDEBAR */}
      <aside className="flex w-full flex-shrink-0 flex-col bg-gradient-to-b from-slate-800 to-slate-900 text-white shadow-xl lg:w-64">
        {/* Logo */}
        <div className="border-b border-slate-700 px-4 py-3 lg:p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3zM16 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM6.5 18a1.5 1.5 0 100-3 1.5 1.5 0 000 3z" />
              </svg>
            </div>
            <div>
              <h1 className="font-bold text-white">CONNECT-Daet</h1>
              <p className="text-xs text-slate-300">Admin Panel</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex flex-1 overflow-x-auto py-2 lg:flex-col lg:overflow-y-auto lg:py-4">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex w-auto flex-shrink-0 items-center gap-3 px-4 py-3 text-left transition-colors lg:w-full lg:flex-shrink lg:px-6 ${
              activeTab === 'dashboard'
                ? 'bg-white/10 border-l-4 border-blue-400 font-semibold'
                : 'hover:bg-white/5'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
            </svg>
            <span className="font-medium">Dashboard</span>
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`flex w-auto flex-shrink-0 items-center gap-3 px-4 py-3 text-left transition-colors lg:w-full lg:flex-shrink lg:px-6 ${
              activeTab === 'orders'
                ? 'bg-white/10 border-l-4 border-blue-400 font-semibold'
                : 'hover:bg-white/5'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
            </svg>
            <span className="font-medium">Orders</span>
            <NavBadge count={badgeOrders} label="orders to handle" />
          </button>

          <button
            onClick={() => setActiveTab('products')}
            className={`flex w-auto flex-shrink-0 items-center gap-3 px-4 py-3 text-left transition-colors lg:w-full lg:flex-shrink lg:px-6 ${
              activeTab === 'products'
                ? 'bg-white/10 border-l-4 border-blue-400 font-semibold'
                : 'hover:bg-white/5'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
            </svg>
            <span className="font-medium">Products</span>
            <NavBadge count={badgeOutOfStock} tone="amber" label="products out of stock" />
          </button>

          <button
            onClick={() => setActiveTab('sellers')}
            className={`flex w-auto flex-shrink-0 items-center gap-3 px-4 py-3 text-left transition-colors lg:w-full lg:flex-shrink lg:px-6 ${
              activeTab === 'sellers'
                ? 'bg-white/10 border-l-4 border-blue-400 font-semibold'
                : 'hover:bg-white/5'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
            </svg>
            <span className="font-medium">Sellers</span>
            <NavBadge count={badgePendingSellers} label="shops waiting for approval" />
          </button>

          <button
            onClick={() => setActiveTab('customers')}
            className={`flex w-auto flex-shrink-0 items-center gap-3 px-4 py-3 text-left transition-colors lg:w-full lg:flex-shrink lg:px-6 ${
              activeTab === 'customers'
                ? 'bg-white/10 border-l-4 border-blue-400 font-semibold'
                : 'hover:bg-white/5'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
            </svg>
            <span className="font-medium">Customers</span>
          </button>

          <button
            onClick={() => setActiveTab('categories')}
            className={`flex w-auto flex-shrink-0 items-center gap-3 px-4 py-3 text-left transition-colors lg:w-full lg:flex-shrink lg:px-6 ${
              activeTab === 'categories'
                ? 'bg-white/10 border-l-4 border-blue-400 font-semibold'
                : 'hover:bg-white/5'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
            </svg>
            <span className="font-medium">Categories</span>
          </button>

          <button
            onClick={() => setActiveTab('transactions')}
            className={`flex w-auto flex-shrink-0 items-center gap-3 px-4 py-3 text-left transition-colors lg:w-full lg:flex-shrink lg:px-6 ${
              activeTab === 'transactions'
                ? 'bg-white/10 border-l-4 border-blue-400 font-semibold'
                : 'hover:bg-white/5'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
            </svg>
            <span className="font-medium">Transactions</span>
          </button>

          <button
            onClick={() => setActiveTab('reports')}
            className={`flex w-auto flex-shrink-0 items-center gap-3 px-4 py-3 text-left transition-colors lg:w-full lg:flex-shrink lg:px-6 ${
              activeTab === 'reports'
                ? 'bg-white/10 border-l-4 border-blue-400 font-semibold'
                : 'hover:bg-white/5'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
            <span className="font-medium">Reports</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex w-auto flex-shrink-0 items-center gap-3 px-4 py-3 text-left transition-colors lg:w-full lg:flex-shrink lg:px-6 ${
              activeTab === 'settings'
                ? 'bg-white/10 border-l-4 border-blue-400 font-semibold'
                : 'hover:bg-white/5'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            <span className="font-medium">Settings</span>
          </button>
        </nav>

        {/* Logout Button */}
        <div className="hidden border-t border-slate-700 p-4 lg:block">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 text-left bg-white/5 text-slate-200 hover:bg-red-500/20 hover:text-white rounded-lg transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
            </svg>
            <span className="font-medium">Log Out</span>
          </button>
        </div>
      </aside>

      {/* MAIN CONTENT AREA */}
      <div className="flex min-h-0 flex-1 flex-col overflow-hidden">
        {/* Top Header */}
        <header className="flex items-center justify-between gap-3 border-b bg-white px-4 py-3 lg:px-8 lg:py-4">
          <div className="min-w-0">
            <h1 className="truncate text-lg font-bold text-gray-900 lg:text-2xl">Welcome back, Admin! 👋</h1>
            <p className="hidden text-sm text-gray-600 sm:block">Here&apos;s what&apos;s happening with your e-commerce platform today.</p>
          </div>
          <div className="flex flex-shrink-0 items-center gap-2 lg:gap-4">
            <NotificationCenter
              audience="admin"
              emptyMessage="Nothing new. The marketplace is running smoothly."
              items={adminNotifications}
              onNavigate={(link) => {
                const tab = new URL(link, window.location.origin).searchParams.get('tab');
                if (tab) setActiveTab(tab);
              }}
            />
            <div className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-100">
                <span className="font-bold text-blue-700">A</span>
              </div>
              <div className="hidden text-right sm:block">
                <p className="max-w-[180px] truncate text-sm font-semibold text-gray-900">{adminName}</p>
                <p className="max-w-[180px] truncate text-xs text-gray-600">{adminEmail || 'Administrator'}</p>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="flex min-h-[44px] items-center rounded-lg px-3 text-sm font-semibold text-red-600 hover:bg-red-50 lg:hidden"
            >
              Log Out
            </button>
          </div>
        </header>

        {/* Scrollable Content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-8">
          {/* Date Display */}
          <div className="mb-4 hidden justify-end sm:flex">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
            </div>
          </div>

          {/* Content */}
          {loading ? (
          <div className="flex justify-center items-center h-64 bg-white rounded-xl">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <p className="text-gray-600">Loading...</p>
            </div>
          </div>
        ) : activeTab === 'dashboard' ? (
          <div>
            {/* Dashboard Stats */}
            <div className="stagger-children grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Orders</p>
                    <h3 className="text-3xl font-bold text-gray-900 mt-2">{stats.totalOrders}</h3>
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                    </svg>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Customers</p>
                    <h3 className="text-3xl font-bold text-gray-900 mt-2">{stats.totalCustomers}</h3>
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                    </svg>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Sellers</p>
                    <h3 className="text-3xl font-bold text-gray-900 mt-2">{stats.totalSellers}</h3>
                    {stats.pendingSellers > 0 && (
                      <p className="text-xs text-amber-700 mt-1">{stats.pendingSellers} pending approval</p>
                    )}
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                    </svg>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Revenue</p>
                    <h3 className="text-3xl font-bold text-gray-900 mt-2">₱{stats.totalSales.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h3>
                  </div>
                  <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 mb-6">
              <h3 className="text-lg font-bold mb-4">Quick Actions</h3>
              <div className="stagger-children grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <button
                  onClick={() => setActiveTab('sellers')}
                  className="flex items-center justify-between p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                      <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                      </svg>
                    </div>
                    <span className="font-semibold text-gray-900">View Sellers</span>
                  </div>
                  {stats.pendingSellers > 0 && (
                    <span className="bg-amber-100 text-amber-800 text-xs font-bold px-2 py-1 rounded-full">{stats.pendingSellers}</span>
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('products')}
                  className="flex items-center justify-between p-4 bg-green-50 hover:bg-green-100 rounded-lg transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
                      <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                      </svg>
                    </div>
                    <span className="font-semibold text-gray-900">Manage Products</span>
                  </div>
                </button>

                <button
                  onClick={() => setActiveTab('orders')}
                  className="flex items-center justify-between p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                      <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                      </svg>
                    </div>
                    <span className="font-semibold text-gray-900">View Orders</span>
                  </div>
                </button>

                <button
                  onClick={() => setActiveTab('customers')}
                  className="flex items-center justify-between p-4 bg-yellow-50 hover:bg-yellow-100 rounded-lg transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-amber-500 rounded-lg flex items-center justify-center">
                      <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                      </svg>
                    </div>
                    <span className="font-semibold text-gray-900">View Customers</span>
                  </div>
                </button>
              </div>
            </div>

            {/* Pending Approvals & Sales Overview Row */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
              {/* Pending Approvals */}
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <h3 className="text-lg font-bold mb-4">Pending Approvals</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-amber-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-amber-500 rounded-lg flex items-center justify-center">
                        <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                        </svg>
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">Seller Applications</p>
                        <p className="text-xs text-gray-600">New registrations</p>
                      </div>
                    </div>
                    <span className="bg-amber-100 text-amber-800 text-sm font-bold px-3 py-1 rounded-full">{stats.pendingSellers}</span>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                        <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                        </svg>
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">Orders to Fulfill</p>
                        <p className="text-xs text-gray-600">Pending, confirmed, processing</p>
                      </div>
                    </div>
                    <span className="bg-blue-500 text-white text-sm font-bold px-3 py-1 rounded-full">{stats.toFulfill}</span>
                  </div>
                </div>
              </div>

              {/* Sales Overview Chart Placeholder */}
              <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold">Sales Overview</h3>
                  <span className="text-xs text-gray-500">Last 7 days</span>
                </div>

                {salesDaily.every(day => day.total === 0) ? (
                  <div className="h-48 flex items-center justify-center bg-gray-50 rounded-lg">
                    <div className="text-center">
                      <p className="text-gray-600 font-medium">No sales in the last 7 days</p>
                      <p className="text-xs text-gray-500 mt-1">Revenue from new orders appears here</p>
                    </div>
                  </div>
                ) : (
                  <div className="h-48 flex items-end gap-2">
                    {salesDaily.map((day) => {
                      const peak = Math.max(...salesDaily.map(entry => entry.total), 1);
                      const height = Math.round((day.total / peak) * 100);

                      return (
                        <div key={day.key} className="flex-1 flex flex-col items-center justify-end h-full">
                          <span className="text-[10px] text-gray-600 mb-1">
                            {day.total > 0 ? `₱${day.total.toLocaleString()}` : ''}
                          </span>
                          <div
                            className="w-full bg-blue-500 rounded-t"
                            style={{ height: `${Math.max(height, 2)}%` }}
                          />
                          <span className="text-[10px] text-gray-500 mt-1">{day.label}</span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* Recent Orders */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold">Recent Orders</h3>
                  <button
                    onClick={() => setActiveTab('orders')}
                    className="text-sm font-semibold text-blue-600 hover:text-blue-700"
                  >
                    View All →
                  </button>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[720px]">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Order ID</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Customer</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Products</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Total</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {orders.slice(0, 5).map((order) => (
                      <tr key={order.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm font-semibold text-gray-900">{formatOrderNumber(order.id)}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">
                          {order.customer_name || 'Customer'}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">
                          {order.shop_order_items?.length || 0} items
                        </td>
                        <td className="px-6 py-4 text-sm font-semibold text-gray-900">
                          ₱{order.total_amount?.toLocaleString() || '0'}
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 text-xs font-semibold rounded-full ${
                            order.status === 'delivered' ? 'bg-green-100 text-green-700' :
                            order.status === 'cancelled' ? 'bg-red-100 text-red-700' :
                            order.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                            'bg-blue-100 text-blue-700'
                          }`}>
                            {statusLabel(order.status, order)}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">
                          {new Date(order.created_at).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                    {orders.length === 0 && (
                      <tr>
                        <td colSpan="6" className="px-6 py-8 text-center text-gray-500">
                          No orders yet
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        ) : activeTab === 'sellers' ? (
          <div>
            <div className="bg-white rounded-xl shadow-sm overflow-x-auto border border-gray-100">
              <table className="w-full min-w-[720px]">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Business Name</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Email</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Phone</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Status</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {sellers.map((seller) => (
                    <tr key={seller.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 font-semibold text-gray-900">{seller.business_name}</td>
                      <td className="px-6 py-4 text-sm text-gray-700">{seller.contact_email}</td>
                      <td className="px-6 py-4 text-sm text-gray-700">{seller.contact_phone || '-'}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 text-xs font-semibold rounded-full ${
                          seller.is_rejected
                            ? 'bg-red-100 text-red-700'
                            : seller.is_approved && seller.is_active
                            ? 'bg-green-100 text-green-700'
                            : !seller.is_approved
                            ? 'bg-yellow-100 text-yellow-700'
                            : 'bg-red-100 text-red-700'
                        }`}>
                          {seller.is_rejected
                            ? 'Rejected'
                            : seller.is_approved && seller.is_active
                            ? 'Active'
                            : !seller.is_approved
                            ? 'Pending Approval'
                            : 'Suspended'}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex flex-wrap items-center gap-2">
                          {!seller.is_approved ? (
                            <button
                              onClick={() => approveSeller(seller)}
                              className={ACTION_STYLES.approve}
                            >
                              Approve
                            </button>
                          ) : (
                            <span className="inline-flex min-h-[36px] items-center gap-1 px-2 text-sm font-medium text-emerald-700">
                              <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                              </svg>
                              Approved
                            </span>
                          )}
                          {!seller.is_approved && !seller.is_rejected && (
                            <button
                              onClick={() => rejectSeller(seller)}
                              className={ACTION_STYLES.reject}
                            >
                              Reject
                            </button>
                          )}
                          <button
                            onClick={() => deleteSeller(seller)}
                            className={ACTION_STYLES.danger}
                          >
                            Delete
                          </button>
                          <button
                            onClick={async () => {
                              try {
                                const newStatus = !seller.is_active;
                                const action = newStatus ? 'activate' : 'suspend';
                                
                                const confirmed = await showConfirm({
                                  tone: newStatus ? 'question' : 'warning',
                                  title: newStatus ? 'Activate this shop?' : 'Suspend this shop?',
                                  message: `"${seller.business_name}" will ${
                                    newStatus ? 'be able to sell again' : 'stop appearing on the storefront'
                                  }.`,
                                  confirmLabel: newStatus ? 'Activate' : 'Suspend',
                                });
                                if (!confirmed) return;
                                
                                const { error } = await supabase
                                  .from('shop_sellers')
                                  .update({ is_active: newStatus, updated_at: new Date().toISOString() })
                                  .eq('id', seller.id);
                                
                                if (error) {
                                  console.error('Error updating seller status:', error);
                                  showToast('Failed to update status: ' + error.message, 'error');
                                  return;
                                }
                                
                                showToast(`Seller ${newStatus ? 'activated' : 'suspended'} successfully!`, 'success');
                                fetchData();
                              } catch (err) {
                                console.error('Error:', err);
                                showToast('Failed to update seller status', 'error');
                              }
                            }}
                            className={seller.is_active ? ACTION_STYLES.pause : ACTION_STYLES.resume}
                          >
                            {seller.is_active ? 'Suspend' : 'Activate'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : activeTab === 'customers' ? (
          <div>
            <div className="bg-white rounded-xl shadow-sm overflow-x-auto border border-gray-100">
              <table className="w-full min-w-[720px]">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Full Name</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Email</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Reward Points</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Status</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Joined</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {customers.length === 0 && (
                    <tr>
                      <td colSpan={6} className="px-6 py-10 text-center text-sm text-gray-500">
                        No customers yet.
                      </td>
                    </tr>
                  )}
                  {customers.map((customer) => (
                    <tr key={customer.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 font-semibold text-gray-900">{customer.full_name || '—'}</td>
                      <td className="px-6 py-4 text-sm text-gray-700">{customer.email || '—'}</td>
                      <td className="px-6 py-4 text-sm font-medium text-blue-600">{(customer.points ?? customer.reward_points) || 0} pts</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          customer.is_suspended
                            ? 'bg-red-100 text-red-700'
                            : 'bg-green-100 text-green-700'
                        }`}>
                          {customer.is_suspended ? 'Suspended' : 'Active'}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-700">{new Date(customer.created_at).toLocaleDateString()}</td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          <button
                            onClick={() => toggleCustomerStatus(customer)}
                            className={customer.is_suspended ? ACTION_STYLES.resume : ACTION_STYLES.pause}
                          >
                            {customer.is_suspended ? 'Reactivate' : 'Suspend'}
                          </button>
                          <button
                            onClick={() => deleteCustomer(customer)}
                            className={ACTION_STYLES.danger}
                          >
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : activeTab === 'products' ? (
          <div>
            <div className="flex justify-between items-center mb-6">
              <div className="flex-1 max-w-md">
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search products..."
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm overflow-x-auto border border-gray-100">
              <table className="w-full min-w-[720px]">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Product</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Category</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Price</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Stock</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Status</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {products
                    .filter(product => 
                      searchTerm === '' || 
                      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                      product.artisan_name?.toLowerCase().includes(searchTerm.toLowerCase())
                    )
                    .map((product) => (
                    <tr key={product.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-4">
                          <div className="w-16 h-16 bg-gray-100 rounded-lg overflow-hidden">
                            {product.image_url ? (
                              <img
                                src={product.image_url}
                                alt={product.name}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center">
                                <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                              </div>
                            )}
                          </div>
                          <div>
                            <div className="font-semibold text-gray-900">{product.name}</div>
                            <div className="text-sm text-gray-600">{product.artisan_name}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="px-3 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-700 capitalize">
                          {product.category}
                        </span>
                      </td>
                      <td className="px-6 py-4 font-semibold text-gray-900">₱{product.price}</td>
                      <td className="px-6 py-4">
                        <span className={`font-semibold ${product.stock > 5 ? 'text-green-600' : product.stock > 0 ? 'text-yellow-600' : 'text-red-600'}`}>
                          {product.stock}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 text-xs font-semibold rounded-full ${
                          product.available ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                        }`}>
                          {product.available ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          <button
                            onClick={() => toggleProductAvailability(product.id, product.available)}
                            className={product.available ? ACTION_STYLES.pause : ACTION_STYLES.resume}
                          >
                            {product.available ? 'Deactivate' : 'Activate'}
                          </button>
                          <button
                            onClick={() => deleteProduct(product.id)}
                            className={ACTION_STYLES.danger}
                          >
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : activeTab === 'orders' ? (
          <div>
            <div className="mb-4 flex flex-col gap-3 sm:flex-row">
              <input
                type="search"
                value={orderSearch}
                onChange={(e) => setOrderSearch(e.target.value)}
                placeholder="Search order number, customer, email or phone..."
                className="min-h-[44px] flex-1 rounded-lg border-2 px-4 focus:border-blue-500 focus:ring-2 focus:ring-blue-500"
              />
              <select
                value={orderStatusFilter}
                onChange={(e) => setOrderStatusFilter(e.target.value)}
                className="min-h-[44px] rounded-lg border-2 px-4"
                aria-label="Filter orders by status"
              >
                <option value="all">All statuses ({orders.length})</option>
                {Object.keys(STATUS_LABELS).map((status) => (
                  <option key={status} value={status}>
                    {STATUS_LABELS[status]} ({orders.filter((order) => order.status === status).length})
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-4">
              {visibleOrders.length === 0 && (
                <div className="rounded-xl border border-gray-100 bg-white p-10 text-center text-gray-500">
                  {orders.length === 0 ? 'No orders yet.' : 'No orders match this search.'}
                </div>
              )}
              {visibleOrders.map((order) => (
                <div key={order.id} className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                  <div className="flex flex-col gap-3 sm:flex-row sm:justify-between sm:items-start mb-4">
                    <div className="min-w-0">
                      <p className="font-mono text-sm font-semibold text-blue-600">{formatOrderNumber(order.id)}</p>
                      <h3 className="font-bold text-lg break-words">{order.customer_name}</h3>
                      <p className="text-sm text-gray-600 break-all">{order.customer_email}</p>
                      <p className="text-sm text-gray-600">{order.customer_phone}</p>
                      {isPickup(order) && (
                        <span className="mt-1 inline-flex rounded-full bg-indigo-100 px-2 py-0.5 text-xs font-semibold text-indigo-800">
                          Store pickup
                        </span>
                      )}
                      <p className="text-sm text-gray-600 break-words whitespace-pre-line">{order.delivery_address}</p>
                      {order.notes && (
                        <p className="mt-2 rounded-lg bg-yellow-50 px-3 py-2 text-sm text-yellow-900 break-words">
                          <span className="font-semibold">Note:</span> {order.notes}
                        </p>
                      )}
                    </div>
                    <div className="sm:text-right">
                      <div className="text-2xl font-bold text-blue-600">{peso(order.total_amount)}</div>
                      {Number(order.shipping_fee) > 0 && (
                        <div className="text-xs text-gray-500">
                          includes {peso(order.shipping_fee)} delivery
                        </div>
                      )}
                      {Number(order.points_discount) > 0 && (
                        <div className="text-xs text-gray-500">
                          after {Number(order.points_redeemed).toLocaleString()} reward points ({peso(order.points_discount)})
                        </div>
                      )}
                      <div className="text-sm text-gray-500">
                        {new Date(order.created_at).toLocaleString('en-PH', { dateStyle: 'medium', timeStyle: 'short' })}
                      </div>
                    </div>
                  </div>

                  <div className="border-t pt-4 mb-4">
                    <h4 className="font-semibold mb-2">Items:</h4>
                    {order.shop_order_items?.map((item, idx) => (
                      <div key={idx} className="text-sm text-gray-600">
                        {item.product_name} x{item.quantity} - {peso(Number(item.price) * Number(item.quantity))}
                        {describeSelection(item.options) && (
                          <span className="block text-xs font-medium text-blue-700">
                            {describeSelection(item.options)}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="flex flex-wrap gap-3 items-center">
                    <span className="text-sm font-medium">Status:</span>
                    <select
                      value={order.status}
                      onChange={(e) => updateOrderStatus(order.id, e.target.value)}
                      disabled={['cancelled', 'delivered'].includes(order.status)}
                      className="min-h-[44px] px-4 py-2 border rounded-lg disabled:bg-gray-100 disabled:text-gray-500"
                    >
                      {allowedStatusesFor(order).map((status) => (
                        <option key={status} value={status}>
                          {statusLabel(status, order)}
                        </option>
                      ))}
                    </select>
                    <span className="text-sm text-gray-600">
                      Payment: {paymentLabel(order.payment_method, order) || 'Unknown'}
                    </span>
                    <OnlinePaymentStatus order={order} />
                  </div>

                  {/* What the customer sent, for a GCash or bank order */}
                  <PaymentProof
                    className="mt-3"
                    url={order.payment_proof_url}
                    reference={order.payment_reference}
                    paidAt={order.payment_proof_at}
                  />
                </div>
              ))}
            </div>
          </div>
        ) : activeTab === 'categories' ? (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold">Manage Categories</h3>
            </div>

            <div className="bg-white rounded-xl shadow-sm overflow-x-auto border border-gray-100">
              <table className="w-full min-w-[720px]">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Icon</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Name</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Slug</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Description</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Order</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Status</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wide">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {categories.map((category) => (
                    <tr key={category.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 text-2xl">{category.icon}</td>
                      <td className="px-6 py-4 font-semibold">{category.name}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{category.slug}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{category.description || '-'}</td>
                      <td className="px-6 py-4 text-sm">{category.display_order}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 text-xs font-semibold rounded-full ${
                          category.is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                        }`}>
                          {category.is_active ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          <button
                            onClick={() => toggleCategoryActive(category)}
                            className={category.is_active ? ACTION_STYLES.pause : ACTION_STYLES.resume}
                          >
                            {category.is_active ? 'Deactivate' : 'Activate'}
                          </button>
                          <button
                            onClick={() => deleteCategory(category)}
                            disabled={category.slug === 'all'}
                            title={category.slug === 'all' ? 'The storefront fallback tab cannot be deleted' : `Delete ${category.name}`}
                            className={ACTION_STYLES.danger}
                          >
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : activeTab === 'transactions' ? (
          <div>
            <div className="mb-6">
              <h3 className="text-xl font-bold mb-2">Transaction Monitoring</h3>
              <p className="text-gray-600 text-sm">Track all payment transactions and financial activities</p>
            </div>

            {/* Transaction Stats */}
            <div className="grid grid-cols-1 gap-6 mb-6 sm:grid-cols-2 xl:grid-cols-6">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                    <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs text-gray-600 font-medium">Completed</p>
                    <p className="text-xl font-bold text-gray-900">₱{orderTotals.completed.toLocaleString()}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <svg className="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs text-gray-600 font-medium">Pending</p>
                    <p className="text-xl font-bold text-gray-900">₱{orderTotals.pending.toLocaleString()}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                    <svg className="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 15L3 9m0 0l6-6M3 9h12a6 6 0 010 12h-3" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs text-gray-600 font-medium">Refunds / Cancelled</p>
                    <p className="text-xl font-bold text-gray-900">₱{orderTotals.refunded.toLocaleString()}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs text-gray-600 font-medium">COD</p>
                    <p className="text-xl font-bold text-gray-900">
                      ₱{orderTotals.cod.toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs text-gray-600 font-medium">GCash</p>
                    <p className="text-xl font-bold text-gray-900">
                      ₱{orderTotals.gcash.toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                    <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs text-gray-600 font-medium">Bank Transfer</p>
                    <p className="text-xl font-bold text-gray-900">
                      ₱{orderTotals.bank.toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                    <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs text-gray-600 font-medium">Paid online (Xendit)</p>
                    <p className="text-xl font-bold text-gray-900">
                      ₱{orderTotals.online.toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Transaction History */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-6 border-b border-gray-200">
                <h4 className="font-bold text-lg">Transaction History</h4>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[720px]">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Transaction ID</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Order ID</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Customer</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Amount</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Payment Method</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {orders.map((order) => (
                      <tr key={order.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm font-mono text-gray-900">TXN-{order.id.slice(0, 8).toUpperCase()}</td>
                        <td className="px-6 py-4 text-sm font-semibold text-blue-600">{formatOrderNumber(order.id)}</td>
                        <td className="px-6 py-4 text-sm text-gray-600">{order.customer_name || 'Customer'}</td>
                        <td className="px-6 py-4 text-sm font-bold text-gray-900">₱{order.total_amount?.toLocaleString()}</td>
                        <td className="px-6 py-4">
                          <span className="px-3 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-700 uppercase">
                            {order.payment_method}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 text-xs font-semibold rounded-full ${
                            order.status === 'delivered' ? 'bg-green-100 text-green-700' :
                            order.status === 'cancelled' ? 'bg-red-100 text-red-700' :
                            order.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                            'bg-blue-100 text-blue-700'
                          }`}>
                            {statusLabel(order.status, order)}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">
                          {new Date(order.created_at).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                    {orders.length === 0 && (
                      <tr>
                        <td colSpan="7" className="px-6 py-8 text-center text-gray-500">
                          No transactions yet
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        ) : activeTab === 'reports' ? (
          <div>
            <div className="mb-6">
              <h3 className="text-xl font-bold mb-2">Reports & Analytics</h3>
              <p className="text-gray-600 text-sm">Generate reports and analyze business performance</p>
            </div>

            {/* Report Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">Sales Report</h4>
                    <p className="text-xs text-gray-600">Daily, weekly, monthly sales</p>
                  </div>
                </div>
                <button
                  onClick={() => generateReport('sales')}
                  disabled={reportLoading !== ''}
                  className="w-full py-2 px-4 bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold rounded-lg transition-colors disabled:opacity-50"
                >
                  {reportLoading === 'sales' ? 'Generating...' : 'Generate Report'}
                </button>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">Product Report</h4>
                    <p className="text-xs text-gray-600">Top selling products</p>
                  </div>
                </div>
                <button
                  onClick={() => generateReport('products')}
                  disabled={reportLoading !== ''}
                  className="w-full py-2 px-4 bg-green-50 hover:bg-green-100 text-green-700 font-semibold rounded-lg transition-colors disabled:opacity-50"
                >
                  {reportLoading === 'products' ? 'Generating...' : 'Generate Report'}
                </button>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">Customer Report</h4>
                    <p className="text-xs text-gray-600">Customer insights & behavior</p>
                  </div>
                </div>
                <button
                  onClick={() => generateReport('customers')}
                  disabled={reportLoading !== ''}
                  className="w-full py-2 px-4 bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold rounded-lg transition-colors disabled:opacity-50"
                >
                  {reportLoading === 'customers' ? 'Generating...' : 'Generate Report'}
                </button>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">Seller Report</h4>
                    <p className="text-xs text-gray-600">Seller performance metrics</p>
                  </div>
                </div>
                <button
                  onClick={() => generateReport('sellers')}
                  disabled={reportLoading !== ''}
                  className="w-full py-2 px-4 bg-yellow-50 hover:bg-yellow-100 text-yellow-700 font-semibold rounded-lg transition-colors disabled:opacity-50"
                >
                  {reportLoading === 'sellers' ? 'Generating...' : 'Generate Report'}
                </button>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">Order Report</h4>
                    <p className="text-xs text-gray-600">Order tracking & status</p>
                  </div>
                </div>
                <button
                  onClick={() => generateReport('orders')}
                  disabled={reportLoading !== ''}
                  className="w-full py-2 px-4 bg-red-50 hover:bg-red-100 text-red-700 font-semibold rounded-lg transition-colors disabled:opacity-50"
                >
                  {reportLoading === 'orders' ? 'Generating...' : 'Generate Report'}
                </button>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">Inventory Report</h4>
                    <p className="text-xs text-gray-600">Stock levels, low & out of stock</p>
                  </div>
                </div>
                <button
                  onClick={() => generateReport('inventory')}
                  disabled={reportLoading !== ''}
                  className="w-full py-2 px-4 bg-purple-50 hover:bg-purple-100 text-purple-700 font-semibold rounded-lg transition-colors disabled:opacity-50"
                >
                  {reportLoading === 'inventory' ? 'Generating...' : 'Generate Report'}
                </button>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">Revenue Report</h4>
                    <p className="text-xs text-gray-600">Revenue analysis & trends</p>
                  </div>
                </div>
                <button
                  onClick={() => generateReport('revenue')}
                  disabled={reportLoading !== ''}
                  className="w-full py-2 px-4 bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold rounded-lg transition-colors disabled:opacity-50"
                >
                  {reportLoading === 'revenue' ? 'Generating...' : 'Generate Report'}
                </button>
              </div>
            </div>

            {/* Generated Report */}
            {report && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mb-6">
                <div className="p-6 border-b border-gray-200 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h4 className="font-bold text-lg">{report.title}</h4>
                    <p className="text-xs text-gray-600">{report.subtitle} · Generated {report.generatedAt}</p>
                  </div>
                  <button
                    onClick={exportReportCsv}
                    className="px-4 py-2 bg-green-100 hover:bg-green-200 text-green-700 font-semibold rounded-lg transition-colors text-sm"
                  >
                    Download CSV
                  </button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[720px]">
                    <thead className="bg-gray-50 border-b border-gray-200">
                      <tr>
                        {report.columns.map((column) => (
                          <th key={column.key} className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                            {column.label}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {report.rows.length === 0 && (
                        <tr>
                          <td colSpan={report.columns.length} className="px-6 py-8 text-center text-gray-500">
                            No data for this report yet. Place some orders first.
                          </td>
                        </tr>
                      )}
                      {report.rows.map((row, index) => (
                        <tr key={index} className="hover:bg-gray-50">
                          {report.columns.map((column) => (
                            <td key={column.key} className="px-6 py-3 text-sm text-gray-700">{row[column.key]}</td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Export Options */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
              <h4 className="font-bold text-lg mb-2">Export Data</h4>
              <p className="text-xs text-gray-600 mb-4">
                Generate a report above, then export it. CSV opens in Excel; Print opens the report on its own
                page, where &quot;Save as PDF&quot; gives you a PDF copy.
              </p>
              <div className="flex flex-wrap gap-3">
                <button
                  onClick={exportReportCsv}
                  className="flex items-center gap-2 px-4 py-2 bg-green-100 hover:bg-green-200 text-green-700 font-semibold rounded-lg transition-colors"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  Export as CSV
                </button>
                <button
                  onClick={printReport}
                  className="flex items-center gap-2 px-4 py-2 bg-red-100 hover:bg-red-200 text-red-700 font-semibold rounded-lg transition-colors"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                  </svg>
                  Print / Save as PDF
                </button>
              </div>
            </div>
          </div>
        ) : activeTab === 'settings' ? (
          <div>
            <div className="mb-6">
              <h3 className="text-xl font-bold mb-2">Settings</h3>
              <p className="text-gray-600 text-sm">Manage website settings and admin account</p>
            </div>

            <div className="space-y-6">
              {/* Admin Account Settings */}
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <h4 className="font-bold text-lg mb-4 flex items-center gap-2">
                  <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                  Admin Account
                </h4>
                <div className="space-y-4">
                  <div className="border-b pb-4">
                    <p className="mb-3 text-sm font-semibold text-gray-700">Profile Picture</p>
                    <AvatarUpload
                      userId={adminUserId}
                      url={adminAvatarUrl}
                      name={adminName}
                      email={adminEmail}
                      onChange={setAdminAvatarUrl}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-gray-700">Email</label>
                    <input
                      type="email"
                      value={adminEmail}
                      disabled
                      className="w-full px-4 py-3 border-2 rounded-lg bg-gray-50 text-gray-600"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-gray-700">Admin Name</label>
                    <input
                      type="text"
                      value={adminName}
                      onChange={(e) => setAdminName(e.target.value)}
                      className="w-full px-4 py-3 border-2 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  <button
                    onClick={updateAdminProfile}
                    className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors"
                  >
                    Update Profile
                  </button>
                </div>
              </div>

              {/* Website Settings */}
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <h4 className="font-bold text-lg mb-4 flex items-center gap-2">
                  <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                  </svg>
                  Website Settings
                </h4>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-gray-700">Website Name</label>
                    <input
                      type="text"
                      value={websiteSettings.siteName}
                      onChange={(e) => setWebsiteSettings({ ...websiteSettings, siteName: e.target.value })}
                      className="w-full px-4 py-3 border-2 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-gray-700">Contact Email</label>
                    <input
                      type="email"
                      value={websiteSettings.contactEmail}
                      onChange={(e) => setWebsiteSettings({ ...websiteSettings, contactEmail: e.target.value })}
                      className="w-full px-4 py-3 border-2 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-gray-700">Contact Phone</label>
                    <input
                      type="tel"
                      value={websiteSettings.contactPhone}
                      onChange={(e) => setWebsiteSettings({ ...websiteSettings, contactPhone: e.target.value })}
                      className="w-full px-4 py-3 border-2 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    />
                  </div>
                  <div className="border-t pt-4">
                    <p className="font-semibold text-gray-900">Payment details shown to buyers</p>
                    <p className="text-xs text-gray-500 mt-1">
                      Buyers who choose GCash or bank transfer see these at checkout and in My Orders. Leave blank to send them yourself when you confirm an order.
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-gray-700">GCash Number</label>
                    <input
                      type="tel"
                      value={websiteSettings.gcashNumber || ''}
                      onChange={(e) => setWebsiteSettings({ ...websiteSettings, gcashNumber: e.target.value })}
                      placeholder="09XX XXX XXXX"
                      className="w-full px-4 py-3 border-2 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-gray-700">GCash Account Name</label>
                    <input
                      type="text"
                      value={websiteSettings.gcashName || ''}
                      onChange={(e) => setWebsiteSettings({ ...websiteSettings, gcashName: e.target.value })}
                      placeholder="e.g. JUAN D."
                      className="w-full px-4 py-3 border-2 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-gray-700">Bank Name</label>
                    <input
                      type="text"
                      value={websiteSettings.bankName || ''}
                      onChange={(e) => setWebsiteSettings({ ...websiteSettings, bankName: e.target.value })}
                      placeholder="e.g. BDO, BPI, Landbank"
                      className="w-full px-4 py-3 border-2 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-gray-700">Bank Account Name</label>
                    <input
                      type="text"
                      value={websiteSettings.bankAccountName || ''}
                      onChange={(e) => setWebsiteSettings({ ...websiteSettings, bankAccountName: e.target.value })}
                      placeholder=""
                      className="w-full px-4 py-3 border-2 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-gray-700">Bank Account Number</label>
                    <input
                      type="text"
                      value={websiteSettings.bankAccountNumber || ''}
                      onChange={(e) => setWebsiteSettings({ ...websiteSettings, bankAccountNumber: e.target.value })}
                      placeholder=""
                      className="w-full px-4 py-3 border-2 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-gray-700">Payment Note (optional)</label>
                    <textarea
                      rows={2}
                      maxLength={300}
                      value={websiteSettings.paymentNote || ''}
                      onChange={(e) => setWebsiteSettings({ ...websiteSettings, paymentNote: e.target.value })}
                      placeholder="e.g. Send a screenshot of your receipt to our Facebook page with your order number."
                      className="w-full px-4 py-3 border-2 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    />
                  </div>
                  <button
                    onClick={saveWebsiteSettings}
                    disabled={savingSettings}
                    className="px-6 py-2.5 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg transition-colors disabled:opacity-50"
                  >
                    {savingSettings ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              </div>

              {/* Delivery fees */}
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <h4 className="font-bold text-lg mb-1 flex items-center gap-2">
                  <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1" />
                  </svg>
                  Delivery Fees
                </h4>
                <p className="mb-4 text-sm text-gray-600">
                  Charged once per shop on each order. The most specific area wins: a city beats its province, and
                  the province beats &quot;Anywhere else&quot;. Set a free-delivery amount to waive the fee on bigger
                  baskets.
                </p>

                {!shippingReady ? (
                  <p className="rounded-lg bg-yellow-50 p-3 text-sm text-yellow-900">
                    Delivery fees are not set up yet. Run <strong>supabase-shipping-chat-gallery.sql</strong> in
                    Supabase.
                  </p>
                ) : (
                  <>
                    <div className="space-y-3">
                      {shippingRates.map((rate) => (
                        <div key={rate.id} className="rounded-lg border border-gray-200 p-3">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <p className="font-semibold text-gray-900">{describeArea(rate)}</p>
                            {rate.province && (
                              <button
                                onClick={() => deleteShippingRate(rate)}
                                className="min-h-[36px] rounded-lg px-3 text-xs font-semibold text-red-600 hover:bg-red-50"
                              >
                                Remove
                              </button>
                            )}
                          </div>

                          <div className="mt-2 grid gap-3 sm:grid-cols-3">
                            <label className="text-xs font-semibold text-gray-600">
                              Fee (₱)
                              <input
                                type="number"
                                min="0"
                                step="0.01"
                                value={rate.fee ?? ''}
                                onChange={(e) =>
                                  setShippingRates((current) =>
                                    current.map((entry) =>
                                      entry.id === rate.id ? { ...entry, fee: e.target.value } : entry
                                    )
                                  )
                                }
                                className="mt-1 w-full min-h-[44px] rounded-lg border-2 px-3 text-sm font-normal text-gray-900"
                              />
                            </label>

                            <label className="text-xs font-semibold text-gray-600">
                              Free over (₱, optional)
                              <input
                                type="number"
                                min="0"
                                step="0.01"
                                value={rate.free_threshold ?? ''}
                                onChange={(e) =>
                                  setShippingRates((current) =>
                                    current.map((entry) =>
                                      entry.id === rate.id ? { ...entry, free_threshold: e.target.value } : entry
                                    )
                                  )
                                }
                                placeholder="Never free"
                                className="mt-1 w-full min-h-[44px] rounded-lg border-2 px-3 text-sm font-normal text-gray-900"
                              />
                            </label>

                            <div className="flex items-end">
                              <button
                                onClick={() => saveShippingRate(rate)}
                                disabled={savingShipping}
                                className="min-h-[44px] w-full rounded-lg bg-blue-600 px-4 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-50"
                              >
                                Save
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="mt-5 rounded-lg border-2 border-dashed border-gray-200 p-3">
                      <p className="mb-2 text-sm font-semibold text-gray-900">Add an area</p>
                      <div className="grid gap-3 sm:grid-cols-4">
                        <input
                          type="text"
                          value={newRate.province}
                          onChange={(e) => setNewRate({ ...newRate, province: e.target.value })}
                          placeholder="Province"
                          className="min-h-[44px] rounded-lg border-2 px-3 text-sm"
                        />
                        <input
                          type="text"
                          value={newRate.city}
                          onChange={(e) => setNewRate({ ...newRate, city: e.target.value })}
                          placeholder="City (optional)"
                          className="min-h-[44px] rounded-lg border-2 px-3 text-sm"
                        />
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          value={newRate.fee}
                          onChange={(e) => setNewRate({ ...newRate, fee: e.target.value })}
                          placeholder="Fee"
                          className="min-h-[44px] rounded-lg border-2 px-3 text-sm"
                        />
                        <button
                          onClick={addShippingRate}
                          disabled={savingShipping}
                          className="min-h-[44px] rounded-lg bg-gray-900 px-4 text-sm font-semibold text-white hover:bg-gray-800 disabled:opacity-50"
                        >
                          Add
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>

              {/* Security Settings */}
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <h4 className="font-bold text-lg mb-4 flex items-center gap-2">
                  <svg className="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                  Security
                </h4>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-gray-700">Current Password</label>
                    <input
                      type="password"
                      value={passwordForm.current}
                      onChange={(e) => setPasswordForm({ ...passwordForm, current: e.target.value })}
                      placeholder="Enter current password"
                      className="w-full px-4 py-3 border-2 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-gray-700">New Password</label>
                    <input
                      type="password"
                      value={passwordForm.next}
                      onChange={(e) => setPasswordForm({ ...passwordForm, next: e.target.value })}
                      placeholder="Enter new password"
                      autoComplete="new-password"
                      className="w-full px-4 py-3 border-2 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                    />
                    <PasswordRequirements value={passwordForm.next} />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2 text-gray-700">Confirm New Password</label>
                    <input
                      type="password"
                      value={passwordForm.confirm}
                      onChange={(e) => setPasswordForm({ ...passwordForm, confirm: e.target.value })}
                      placeholder="Confirm new password"
                      className="w-full px-4 py-3 border-2 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                    />
                  </div>
                  <button
                    onClick={changeAdminPassword}
                    disabled={!isPasswordValid(passwordForm.next)}
                    className="px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-lg transition-colors disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    Change Password
                  </button>
                </div>
              </div>

              {/* Danger zone */}
              <div className="rounded-xl border-2 border-rose-200 bg-white p-6 shadow-sm">
                <h4 className="mb-1 flex items-center gap-2 text-lg font-bold text-rose-700">
                  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                  Reset Marketplace Data
                </h4>
                <p className="mb-4 text-sm text-gray-600">
                  Start the sales figures from zero, for example after testing or a demo. This deletes every order,
                  sale, payment, seller earning and the reward points customers earned or spent in the shop, and puts
                  stock held by undelivered orders back on sale. <strong>Accounts, shops, products, categories,
                  delivery fees and settings are kept.</strong>
                </p>

                <fieldset className="mb-4 space-y-2">
                  <legend className="mb-2 text-sm font-semibold text-gray-900">Also delete</legend>
                  {[
                    { key: 'reviews', label: 'All product reviews and ratings' },
                    { key: 'messages', label: 'All chats between customers and shops' },
                    { key: 'notifications', label: 'All notifications (the bell) for everyone' },
                  ].map((option) => (
                    <label key={option.key} className="flex min-h-[36px] cursor-pointer items-center gap-3 text-sm text-gray-700">
                      <input
                        type="checkbox"
                        checked={resetOptions[option.key]}
                        onChange={(event) =>
                          setResetOptions((current) => ({ ...current, [option.key]: event.target.checked }))
                        }
                        className="h-4 w-4 rounded border-gray-300 text-rose-600 focus:ring-rose-500"
                      />
                      {option.label}
                    </label>
                  ))}
                </fieldset>

                <label htmlFor="resetConfirm" className="mb-1 block text-sm font-medium text-gray-700">
                  Type <span className="font-mono font-bold text-rose-700">RESET</span> to confirm
                </label>
                <div className="flex flex-col gap-3 sm:flex-row">
                  <input
                    id="resetConfirm"
                    type="text"
                    autoComplete="off"
                    value={resetConfirm}
                    onChange={(event) => setResetConfirm(event.target.value.toUpperCase())}
                    placeholder="RESET"
                    className="w-full rounded-lg border-2 px-4 py-3 font-mono tracking-widest focus:border-rose-500 focus:ring-2 focus:ring-rose-500 sm:max-w-xs"
                  />
                  <button
                    type="button"
                    onClick={resetMarketplace}
                    disabled={resetConfirm.trim() !== 'RESET' || resetting}
                    className="min-h-[48px] rounded-lg bg-rose-600 px-6 font-semibold text-white transition-colors hover:bg-rose-700 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    {resetting ? 'Resetting...' : 'Reset Marketplace Data'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : null}
        </main>
      </div>

    </div>
  );
}
