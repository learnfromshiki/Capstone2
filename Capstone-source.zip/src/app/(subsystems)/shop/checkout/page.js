'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import CheckoutModal from '@/components/shop/CheckoutModal';
import { loadCart, readLocalCart, saveCart } from '@/lib/cart';
import { clearBuyNow, readBuyNow } from '@/lib/buyNow';
import { clearSelection, readSelection } from '@/lib/checkoutSelection';

/**
 * The checkout page.
 *
 * Two ways in:
 *   /shop/checkout              - the lines ticked in the cart (everything,
 *                                 when nothing was ticked in particular)
 *   /shop/checkout?mode=buynow  - one item bought straight away, which is
 *                                 never added to the cart
 *
 * Whatever arrives here, place_order() prices and checks every line again on
 * the server, so a tampered selection buys nothing it should not.
 */
export default function CheckoutPage() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();

  const [mode, setMode] = useState('cart');
  const [items, setItems] = useState([]);
  const [ready, setReady] = useState(false);

  const cartKey = user ? `shop_cart:${user.id}` : null;

  useEffect(() => {
    if (authLoading) return;

    if (!user) {
      router.push('/shop');
      return;
    }

    const requested =
      new URLSearchParams(window.location.search).get('mode') === 'buynow' ? 'buynow' : 'cart';
    setMode(requested);

    if (requested === 'buynow') {
      const line = readBuyNow(user.id);
      setItems(line ? [line] : []);
      setReady(true);
      return;
    }

    let cancelled = false;

    // The cart saved in the database (the same on every device).
    loadCart(user.id)
      .then((lines) => {
        if (cancelled) return;

        // Only what the customer ticked in the cart. A selection that no
        // longer matches anything (the cart changed in another tab) falls back
        // to the whole cart rather than an empty checkout.
        const chosen = readSelection(user.id);
        const picked = chosen ? lines.filter((line) => chosen.includes(line.lineId)) : lines;

        setItems(picked.length > 0 ? picked : lines);
      })
      .catch((error) => {
        console.error('Could not read your cart:', error);
        if (!cancelled) setItems([]);
      })
      .finally(() => {
        if (!cancelled) setReady(true);
      });

    return () => {
      cancelled = true;
    };
  }, [authLoading, user, router, cartKey]);

  const total = useMemo(
    () =>
      items.reduce((sum, item) => sum + (Number(item.price) || 0) * (Number(item.quantity) || 0), 0),
    [items]
  );

  // Called more than once (order placed, then "Continue Shopping"); the cart
  // is only updated the first time.
  const cartClearedRef = useRef(null);

  const handleSuccess = () => {
    if (!user) return Promise.resolve();

    if (mode === 'buynow') {
      clearBuyNow(user.id);
      return Promise.resolve();
    }

    if (cartClearedRef.current) return cartClearedRef.current;

    // Take out only what was just bought; anything left unticked stays in the
    // cart for next time.
    const bought = new Set(items.map((item) => item.lineId));
    const remaining = readLocalCart(user.id).filter((item) => !bought.has(item.lineId));
    // Saved straight away: the next step may be a redirect to Xendit.
    cartClearedRef.current = saveCart(user.id, remaining, { immediate: true });

    clearSelection(user.id);
    return cartClearedRef.current;
  };

  if (authLoading || !ready) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-gray-50">
        <div className="h-12 w-12 animate-spin rounded-full border-b-2 border-blue-600" />
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-gray-50">
      <header className="border-b bg-white">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-4 py-4 sm:px-6">
          <Link href="/shop" className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-600 text-white">
              <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
            </span>
            <span>
              <span className="block text-lg font-bold text-gray-900">Checkout</span>
              <span className="block text-xs text-gray-500">
                {mode === 'buynow'
                  ? 'Buying one item'
                  : `${items.length} ${items.length === 1 ? 'item' : 'items'} from your cart`}
              </span>
            </span>
          </Link>

          <Link href="/shop" className="min-h-[44px] text-sm font-medium text-blue-600 hover:text-blue-700">
            ← Keep shopping
          </Link>
        </div>
      </header>

      <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
        {items.length === 0 ? (
          <div className="mx-auto max-w-md rounded-2xl bg-white p-10 text-center shadow-sm">
            <h1 className="text-xl font-bold text-gray-900">Nothing to check out</h1>
            <p className="mt-2 text-sm text-gray-600">
              {mode === 'buynow'
                ? 'This purchase has already been completed, or the page was reloaded.'
                : 'Your cart is empty.'}
            </p>
            <Link
              href="/shop"
              className="mt-6 inline-flex min-h-[44px] items-center rounded-full bg-blue-600 px-6 font-bold text-white hover:bg-blue-700"
            >
              Browse the shop
            </Link>
          </div>
        ) : (
          <CheckoutModal
            variant="page"
            cart={items}
            total={total}
            onClose={() => router.push('/shop')}
            onSuccess={handleSuccess}
            onRequireAuth={() => router.push('/shop')}
          />
        )}
      </div>
    </main>
  );
}
